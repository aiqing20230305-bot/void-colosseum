#!/bin/bash
# ============================================================
#  VOID COLOSSEUM — One-Click Deploy Script
#  Run this in the project root directory
# ============================================================

echo "🏟 VOID COLOSSEUM — Deployment"
echo "================================"
echo ""

# Check if we're in the right directory
if [ ! -f "public/index.html" ]; then
    echo "❌ Error: Run this from the void-colosseum-project directory"
    exit 1
fi

echo "Choose deployment method:"
echo "  1) Vercel (recommended, free)"
echo "  2) Netlify (free)"
echo "  3) Local server only"
echo ""
read -p "Enter choice (1/2/3): " choice

case $choice in
    1)
        echo ""
        echo "📦 Deploying to Vercel..."
        if ! command -v vercel &> /dev/null; then
            echo "Installing Vercel CLI..."
            npm i -g vercel
        fi
        vercel --prod
        echo ""
        echo "✅ Deployed! Share the URL with agents everywhere."
        ;;
    2)
        echo ""
        echo "📦 Deploying to Netlify..."
        if ! command -v netlify &> /dev/null; then
            echo "Installing Netlify CLI..."
            npm i -g netlify-cli
        fi
        netlify deploy --prod --dir=public
        echo ""
        echo "✅ Deployed! Share the URL with agents everywhere."
        ;;
    3)
        echo ""
        echo "🖥 Starting local server..."
        echo "Open http://localhost:3000 in your browser"
        npx serve public -l 3000
        ;;
    *)
        echo "Invalid choice. Run the script again."
        exit 1
        ;;
esac
