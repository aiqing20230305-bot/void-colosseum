#!/usr/bin/env python3
"""
VOID COLOSSEUM — Quick Test
Run this to verify the game engine works and see agents battle.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from void_colosseum import (
    Arena, Tournament,
    GreedyAgent, RandomAgent, LLMAgent,
)

def main():
    print("=" * 60)
    print("🏟 VOID COLOSSEUM — Engine Test Suite")
    print("=" * 60)
    print()

    # Test 1: Single game
    print("📋 Test 1: Single Game (Greedy vs Random)")
    print("-" * 40)
    arena = Arena(seed=42)
    result = arena.fight(GreedyAgent("Greedy"), RandomAgent("Random"), verbose=True)
    assert result["winner"] in ["a", "b", "draw"], "Invalid winner"
    assert result["turns"] > 0, "No turns played"
    print(f"   ✅ Game completed in {result['turns']} turns")
    print()

    # Test 2: Multiple seeds
    print("📋 Test 2: 10 Games with Different Seeds")
    print("-" * 40)
    greedy_wins = 0
    for seed in range(10):
        arena = Arena(seed=seed * 1000 + 1)
        result = arena.fight(GreedyAgent("G"), RandomAgent("R"))
        if result["winner"] == "a":
            greedy_wins += 1
    print(f"   Greedy won {greedy_wins}/10 games ({greedy_wins * 10}% win rate)")
    assert greedy_wins >= 3, "Greedy should win more than random"
    print(f"   ✅ Strategy advantage confirmed")
    print()

    # Test 3: Custom agent
    print("📋 Test 3: Custom LLM Agent (Simulated)")
    print("-" * 40)

    def smart_brain(state):
        """A smarter-than-random agent."""
        pos = state["you"]["pos"]
        cells = state["visible_cells"]

        # Find gold, avoid traps
        golds = [c for c in cells if c["type"] == "gold"]
        traps = {(c["x"], c["y"]) for c in cells if c["type"] == "trap"}

        if golds:
            # Go to highest value/distance ratio
            best = max(golds, key=lambda g:
                       g.get("value", 10) / (abs(g["x"] - pos[0]) + abs(g["y"] - pos[1]) + 1))
            dx = best["x"] - pos[0]
            dy = best["y"] - pos[1]

            # Check for traps in the way
            if abs(dx) > abs(dy):
                move = "right" if dx > 0 else "left"
                nx = pos[0] + (1 if dx > 0 else -1)
                if (nx, pos[1]) in traps:
                    move = "down" if dy > 0 else "up"  # Detour
            else:
                move = "down" if dy > 0 else "up"
                ny = pos[1] + (1 if dy > 0 else -1)
                if (pos[0], ny) in traps:
                    move = "right" if dx > 0 else "left"  # Detour

            sprint = state["you"]["energy"] >= 5 and abs(dx) + abs(dy) > 4
        else:
            move = ["up", "down", "left", "right"][state["turn"] % 4]
            sprint = False

        # Use items
        use_item = None
        items = state["you"]["items"]
        if "heal" in items and state["you"]["hp"] < 50:
            use_item = "heal"
        elif "reveal" in items and state["turn"] < 15:
            use_item = "reveal"

        return {
            "move": move,
            "sprint": sprint,
            "use_item": use_item,
            "trash_talk": "Calculated. 📐" if state["turn"] % 10 == 0 else ""
        }

    arena = Arena(seed=777)
    result = arena.fight(
        LLMAgent("SmartBot", decide_fn=smart_brain),
        GreedyAgent("Baseline"),
        verbose=True
    )
    print(f"   ✅ Custom agent completed successfully")
    print()

    # Test 4: Tournament
    print("📋 Test 4: Mini Tournament (4 agents, 3 rounds)")
    print("-" * 40)
    agents = [
        LLMAgent("SmartBot", decide_fn=smart_brain),
        GreedyAgent("Greedy-A"),
        GreedyAgent("Greedy-B"),
        RandomAgent("Chaos"),
    ]
    tournament = Tournament(agents, rounds=3)
    results = tournament.round_robin(verbose=True)
    print(f"   ✅ Tournament completed")
    print()

    # Test 5: Replay
    print("📋 Test 5: Replay System")
    print("-" * 40)
    arena = Arena(seed=12345)
    result = arena.fight(GreedyAgent("A"), GreedyAgent("B"))
    print(f"   Replay frames: {result['replay_frames']}")
    print(f"   Log entries: {len(result['log'])}")
    assert result["replay_frames"] > 0, "No replay frames"
    print(f"   ✅ Replay system working")
    print()

    print("=" * 60)
    print("🎉 ALL TESTS PASSED!")
    print("=" * 60)
    print()
    print("Next steps:")
    print("  1. Deploy: bash scripts/deploy.sh")
    print("  2. Build your agent: see docs/STRATEGY_GUIDE.md")
    print("  3. Join the arena: https://void-colosseum.vercel.app")
    print()


if __name__ == "__main__":
    main()
